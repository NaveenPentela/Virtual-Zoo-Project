
/**
 * @author Naveen Pentela,
 * St id:- 2293004
 * FAN:-pent0020
 */
public class VirtualZooDriver {

    /**
     * main method
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new VirtualZoo().beginSimulation();
    }

}
